﻿# ADM-MANAGER-MOD

# ESTE PROYECTO A SIDO DESCONTINUADO.--

![logo](https://raw.githubusercontent.com/AAAAAEXQOSyIpN2JZ0ehUQ/ADM-MANAGER-MOD/master/ADM_MANAGER_MOD.jpg)

**Manager Script**

## :heavy_exclamation_mark: Requerimientos

1 • RECOMENDADO UBUNTU 14.04

2 • USAR DISTRIBUCION NUEVA O FORMATIADA

## Installation

apt-get update -y; apt-get upgrade -y; wget https://raw.githubusercontent.com/AAAAAEXQOSyIpN2JZ0ehUQ/ADM-MANAGER-MOD/master/instala.sh; chmod +x instala.sh; ./instala.sh

```
* SIN MINERIA! 
* SIN KEYS! 
* VERSION GRATUITA 
* SIN VIRUS TROJANO (BOTNET) 
* ARCHIVOS LIBERADOS (DECENCRIPTADOS)
```

```
☆ https://t.me/admmanagerfree ☆

☆ https://github.com/AAAAAEXQOSyIpN2JZ0ehUQ ☆
```

**By: [ FULL SCRIPTS ⃘⃤꙰✰ ]**